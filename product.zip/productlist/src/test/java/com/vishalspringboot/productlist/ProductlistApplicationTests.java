package com.vishalspringboot.productlist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductlistApplicationTests {

	@Test
	void contextLoads() {
	}

}
